---
'fingerprint-pro-server-api-openapi': minor
---

**events**: Add `raw_device_attributes` field exposing browser fingerprinting signals
