---
'fingerprint-pro-server-api-openapi': minor
---

Add `ClientReferrer` field to the Event
