---
'fingerprint-pro-server-api-openapi': minor
---

**events-search**: Add `tor_node` filter parameter
