---
'fingerprint-pro-server-api-openapi': minor
---

Add `asn_type` field to the IPInfo signals