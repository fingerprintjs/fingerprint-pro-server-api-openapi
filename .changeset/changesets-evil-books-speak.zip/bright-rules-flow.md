---
'fingerprint-pro-server-api-openapi': minor
---

**events**: Add `rule_action` field and `ruleset_id` query parameter for evaluating events against rulesets
