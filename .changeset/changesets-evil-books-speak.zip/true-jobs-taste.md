---
'fingerprint-pro-server-api-openapi': patch
---

Add `service_unavailable` error code
