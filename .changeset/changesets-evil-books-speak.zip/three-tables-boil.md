---
'fingerprint-pro-server-api-openapi': minor
---

**events-search**: Add `asn` and `proximity_id` filters to `searchEvents` method