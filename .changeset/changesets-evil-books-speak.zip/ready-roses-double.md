---
'fingerprint-pro-server-api-openapi': minor
---

Add `HighActivity` signal
