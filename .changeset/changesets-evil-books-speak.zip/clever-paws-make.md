---
'fingerprint-pro-server-api-openapi': minor
---

**webhook**: require event payload
