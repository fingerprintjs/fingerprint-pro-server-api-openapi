---
'fingerprint-pro-server-api-openapi': major
---

Migrate to API v4
We simplified the API response structure and removed deprecated endpoints. Please refer to the [Migration Guide](https://dev.fingerprint.com/reference/migrating-from-server-api-v3-to-v4#/) for details on the new API structure and available endpoints.
