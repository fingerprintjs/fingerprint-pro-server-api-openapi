---
'fingerprint-pro-server-api-openapi': minor
---

Add `confidence` property to the Proxy detection Smart Signal, which now supports both residential and public web proxies.