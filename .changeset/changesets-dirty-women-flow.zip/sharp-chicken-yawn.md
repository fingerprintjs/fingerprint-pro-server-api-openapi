---
'fingerprint-pro-server-api-openapi': patch
---

**events**: Update Tampering descriptions to reflect Android support.