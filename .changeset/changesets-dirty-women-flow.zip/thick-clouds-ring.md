---
"fingerprint-pro-server-api-openapi": patch
---

**webhook**: Add `environmentId` property
