---
'fingerprint-pro-server-api-openapi': minor
---

**related-visitors**: Add GET `/related-visitors` endpoint