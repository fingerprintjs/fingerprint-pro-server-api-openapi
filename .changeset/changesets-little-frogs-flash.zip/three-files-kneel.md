---
'fingerprint-pro-server-api-openapi': minor
---

**events**: Add `antiDetectBrowser` detection method to the `tampering` Smart Signal.
