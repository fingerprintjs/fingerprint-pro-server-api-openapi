---
'fingerprint-pro-server-api-openapi': minor
---

Added new `ipEvents`, `distinctIpByLinkedId`, and `distinctVisitorIdByLinkedId` fields to the `velocity` Smart Signal.
