---
'fingerprint-pro-server-api-openapi': patch
---

- Fix descriptions formatting:
  - Remove extra line breaks.
  - Fix block styles.
- Fix links in descriptions.