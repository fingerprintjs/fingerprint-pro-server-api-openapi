---
'fingerprint-pro-server-api-openapi': minor
---

Add `environmentId` property to `identification`