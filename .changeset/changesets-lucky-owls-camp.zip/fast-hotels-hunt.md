---
'fingerprint-pro-server-api-openapi': minor
---

**webhook**: Add `supplementaryIds` property to the Webhooks schema.