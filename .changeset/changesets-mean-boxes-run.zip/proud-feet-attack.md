---
"fingerprint-pro-server-api-openapi": minor
---

Add `proximity` signal that represents a fixed geographical zone in a discrete global grid within which the device is observed.
