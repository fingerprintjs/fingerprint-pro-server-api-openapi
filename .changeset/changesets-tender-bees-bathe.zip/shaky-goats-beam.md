---
'fingerprint-pro-server-api-openapi': patch
---

**webhook**: Apply x-flatten-optional-params: true in correct place in the webhook.yaml