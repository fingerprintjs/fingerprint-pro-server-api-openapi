---
'fingerprint-pro-server-api-openapi': minor
---

add `replayed` field to `identification` in Events and Webhooks