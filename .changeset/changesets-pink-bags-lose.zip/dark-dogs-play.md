---
'fingerprint-pro-server-api-openapi': minor
---

Mark `replayed` field required in the `identification` product schema. This field will always be present.