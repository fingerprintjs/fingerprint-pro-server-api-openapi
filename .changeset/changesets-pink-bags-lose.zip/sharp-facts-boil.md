---
'fingerprint-pro-server-api-openapi': minor
---

Add `sdk` field with platform metadata to `identification`