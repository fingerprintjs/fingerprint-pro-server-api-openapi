---
'fingerprint-pro-server-api-openapi': patch
---

Deprecate the Remote Control Detection Smart Signal. This signal is no longer available.