---
'fingerprint-pro-server-api-openapi': minor
---

**events-search**: Add a new `events/search` API endpoint. Allow users to search for identification events matching one or more search criteria, for example, visitor ID, IP address, bot detection result, etc.
