---
'fingerprint-pro-server-api-openapi': minor
---

Add `relay` detection method to the VPN Detection Smart Signal
