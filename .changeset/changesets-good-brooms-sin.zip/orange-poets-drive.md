---
'fingerprint-pro-server-api-openapi': minor
---

**events**: Add a `suspect` field to the `identification` product schema