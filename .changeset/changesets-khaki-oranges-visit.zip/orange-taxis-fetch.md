---
'fingerprint-pro-server-api-openapi': minor
---

**visitors**: Add the confidence field to the VPN Detection Smart Signal