---
"fingerprint-pro-server-api-openapi": patch
---

Add APIv3 deprecation notice.
This version of Server API is marked as deprecated starting on **Oct 31st 2025** and will be fully defunct on **Oct 31st 2026** according to our [API Deprecation Policy](https://dev.fingerprint.com/reference/api-deprecation-policy).
If you still use this version, please follow our [migration guide](https://dev.fingerprint.com/reference/migrating-from-server-api-v3-to-v4) to migrate from this deprecated version to the new one.
