---
'fingerprint-pro-server-api-openapi': minor
---

**events-search**: Add 'pagination_key' parameter