---
"fingerprint-pro-server-api-openapi": minor
---

Add `mitmAttack` (man-in-the-middle attack) Smart Signal.
