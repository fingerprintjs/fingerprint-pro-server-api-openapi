---
'fingerprint-pro-server-api-openapi': patch
---

**events-search**: Fixed `vpn_confidence` query parameter enum value formatting (`high,` -> `high`)
