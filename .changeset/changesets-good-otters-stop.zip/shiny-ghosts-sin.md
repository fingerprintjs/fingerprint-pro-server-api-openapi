---
'fingerprint-pro-server-api-openapi': minor
---

**events-search**: Event search now supports two new filter parameters: `ip_blocklist`, `datacenter`
