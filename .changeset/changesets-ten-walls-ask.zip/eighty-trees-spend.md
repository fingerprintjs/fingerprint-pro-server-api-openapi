---
'fingerprint-pro-server-api-openapi': patch
---

**related-visitors**: Add mention that the API is billable