---
'fingerprint-pro-server-api-openapi': patch
---

**events-search**: Fix `searchEvents` method description