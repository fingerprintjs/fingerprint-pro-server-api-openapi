---
'fingerprint-pro-server-api-openapi': patch
---

Fix errors examples `403_feature_not_enabled` and `403_subscription_not_active`.