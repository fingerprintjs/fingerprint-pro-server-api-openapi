---
'fingerprint-pro-server-api-openapi': minor
---

Remove `ipv4` format from `ip` field in `Botd`, `Identification`, `Visit` and `Webhook` models.