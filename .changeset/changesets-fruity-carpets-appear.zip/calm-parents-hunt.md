---
'fingerprint-pro-server-api-openapi': patch
---

**events-search**: Improve parameter descriptions for `bot`, `suspect`